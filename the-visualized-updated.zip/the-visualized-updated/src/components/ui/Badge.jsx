const VARIANTS = {
  default:  'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400',
  indigo:   'bg-indigo-100 dark:bg-indigo-950/50 text-indigo-700 dark:text-indigo-300',
  purple:   'bg-purple-100 dark:bg-purple-950/50 text-purple-700 dark:text-purple-300',
  cyan:     'bg-cyan-100 dark:bg-cyan-950/50 text-cyan-700 dark:text-cyan-300',
  emerald:  'bg-emerald-100 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300',
  amber:    'bg-amber-100 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300',
  rose:     'bg-rose-100 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300',
  success:  'bg-emerald-100 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400',
  warning:  'bg-amber-100 dark:bg-amber-950/50 text-amber-700 dark:text-amber-400',
  danger:   'bg-rose-100 dark:bg-rose-950/50 text-rose-700 dark:text-rose-400',
  info:     'bg-blue-100 dark:bg-blue-950/50 text-blue-700 dark:text-blue-400',
};

export default function Badge({ children, variant = 'default', className = '' }) {
  return (
    <span className={`inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-full
                      ${VARIANTS[variant] || VARIANTS.default} ${className}`}>
      {children}
    </span>
  );
}
