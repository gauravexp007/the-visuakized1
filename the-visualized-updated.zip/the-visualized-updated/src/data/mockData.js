// ── Mock data for AI Learning & Productivity Assistant ──────────────────────

// Dashboard: daily study hours for the past 7 days
export const dailyStudyData = [
  { day: 'Mon', hours: 3.5, coding: 1.5, reading: 1.0, videos: 1.0 },
  { day: 'Tue', hours: 4.2, coding: 2.0, reading: 1.2, videos: 1.0 },
  { day: 'Wed', hours: 2.8, coding: 1.0, reading: 0.8, videos: 1.0 },
  { day: 'Thu', hours: 5.1, coding: 2.5, reading: 1.6, videos: 1.0 },
  { day: 'Fri', hours: 3.9, coding: 1.8, reading: 1.1, videos: 1.0 },
  { day: 'Sat', hours: 6.0, coding: 3.0, reading: 2.0, videos: 1.0 },
  { day: 'Sun', hours: 4.5, coding: 2.0, reading: 1.5, videos: 1.0 },
];

// Dashboard: time distribution by platform
export const platformDistribution = [
  { name: 'Coding',  value: 38, color: '#6366f1' },
  { name: 'Reading', value: 27, color: '#8b5cf6' },
  { name: 'Videos',  value: 19, color: '#06b6d4' },
  { name: 'Writing', value: 16, color: '#10b981' },
];

// Dashboard: weekly progress trend (4 weeks)
export const weeklyTrend = [
  { week: 'Week 1', score: 62 },
  { week: 'Week 2', score: 71 },
  { week: 'Week 3', score: 68 },
  { week: 'Week 4', score: 84 },
];

// Dashboard: AI suggestions
export const aiSuggestions = [
  {
    id: 1,
    type: 'warning',
    title: 'Reading time is declining',
    body: 'You spent 22% less time reading this week. Try scheduling 30 min of reading each morning.',
    icon: 'BookOpen',
  },
  {
    id: 2,
    type: 'success',
    title: 'Great coding streak!',
    body: 'Your coding hours increased by 15% — keep it up to reach your weekly goal.',
    icon: 'Code2',
  },
  {
    id: 3,
    type: 'info',
    title: 'Recommended: Data Structures',
    body: 'Based on weak areas detected, revisit linked lists and binary trees this weekend.',
    icon: 'Lightbulb',
  },
];

// Email mock data
export const mockEmails = [
  {
    id: 1,
    from: 'prof.johnson@university.edu',
    fromName: 'Prof. Johnson',
    subject: 'Assignment 3 Deadline Extended',
    preview: 'Good news — the deadline for Assignment 3 has been extended to next Friday...',
    body: `Good news everyone,\n\nI wanted to let you know that the deadline for Assignment 3 has been extended to next Friday, April 5th, at 11:59 PM. Please make sure to submit through the portal.\n\nBest regards,\nProf. Johnson`,
    time: '10:32 AM',
    date: '2026-03-20',
    category: 'important',
    read: false,
    summary: 'Assignment 3 deadline has been extended to April 5th at 11:59 PM. Submit through the portal.',
  },
  {
    id: 2,
    from: 'hr@techcorp.com',
    fromName: 'TechCorp HR',
    subject: 'Interview Invitation — Software Engineer Role',
    preview: 'We were impressed with your application and would like to invite you for...',
    body: `Dear Candidate,\n\nWe were impressed with your application and would like to invite you for a technical interview for the Software Engineer position at TechCorp.\n\nPlease select a time slot from the link below.\n\nBest,\nTechCorp Recruiting`,
    time: '9:15 AM',
    date: '2026-03-20',
    category: 'important',
    read: false,
    summary: 'Interview invitation for Software Engineer role at TechCorp. Need to select a time slot.',
  },
  {
    id: 3,
    from: 'newsletter@medium.com',
    fromName: 'Medium Daily Digest',
    subject: 'Your daily stories: AI, React, and more',
    preview: 'Top stories picked for you: "The Future of AI in Education", "React 19 Features"...',
    body: `Today's top stories curated for you:\n\n1. The Future of AI in Education\n2. React 19 New Features Explained\n3. Building Scalable APIs with FastAPI\n\nRead more at medium.com`,
    time: '8:00 AM',
    date: '2026-03-20',
    category: 'normal',
    read: true,
    summary: 'Daily digest with articles on AI in education, React 19, and FastAPI.',
  },
  {
    id: 4,
    from: 'promo@shopping.com',
    fromName: 'ShopDeals',
    subject: '🎉 50% OFF Everything — Today Only!',
    preview: 'Flash sale! Don\'t miss out on massive discounts across all categories...',
    body: `MASSIVE SALE — 50% OFF EVERYTHING!\n\nDon't miss this once-in-a-lifetime deal. Shop now before it expires!\n\nUnsubscribe | View in browser`,
    time: '7:30 AM',
    date: '2026-03-20',
    category: 'spam',
    read: true,
    summary: 'Promotional email with flash sale discount.',
  },
  {
    id: 5,
    from: 'team@github.com',
    fromName: 'GitHub',
    subject: 'New pull request on your repository',
    preview: 'alexdev opened a pull request: "Add dark mode support" in awesome-project...',
    body: `alexdev opened a pull request: "Add dark mode support"\n\nRepository: awesome-project\nBranch: feature/dark-mode → main\n\nView the pull request on GitHub.`,
    time: 'Yesterday',
    date: '2026-03-19',
    category: 'normal',
    read: true,
    summary: 'New PR "Add dark mode support" opened in awesome-project repository.',
  },
];

// Chatbot: conversation history sample
export const sampleChatHistory = [
  {
    role: 'assistant',
    content: 'Hi! I\'m your AI Study Assistant. Upload a PDF or ask me anything — I can explain concepts, solve doubts, and generate examples. How can I help you today?',
    timestamp: new Date(Date.now() - 60000),
  },
];

// Chatbot: quick prompts
export const quickPrompts = [
  'Explain this concept simply',
  'Give me 3 examples',
  'Create a quiz from this topic',
  'What are the key takeaways?',
  'Compare and contrast',
  'Summarize in bullet points',
];

// PDF analyzer: sample extracted content
export const samplePDFResult = {
  title: 'Introduction to Machine Learning',
  pageCount: 24,
  wordCount: 8420,
  summary: {
    short: 'This document introduces core machine learning concepts including supervised learning, unsupervised learning, and reinforcement learning. It covers algorithms like linear regression, decision trees, and neural networks, with practical use cases.',
    detailed: `Machine Learning (ML) is a branch of artificial intelligence that enables systems to learn from data and improve performance without explicit programming.\n\nThe document covers three main paradigms:\n1. **Supervised Learning** — Learning from labeled data (e.g., spam detection, image classification)\n2. **Unsupervised Learning** — Finding hidden patterns in unlabeled data (e.g., clustering, dimensionality reduction)\n3. **Reinforcement Learning** — Learning through reward/penalty feedback (e.g., game playing, robotics)\n\nKey algorithms discussed include linear regression, logistic regression, decision trees, random forests, support vector machines, and deep neural networks. The document also covers model evaluation metrics, overfitting/underfitting, and hyperparameter tuning.`,
  },
  eli5: 'Imagine you\'re teaching a baby to recognize cats. First, you show it thousands of cat photos and say "cat!" each time. Eventually the baby learns to spot cats on its own. That\'s supervised learning! Machine learning works the same way — we feed computers lots of examples so they learn patterns and can make predictions on new data.',
  keyPoints: [
    'ML enables computers to learn from data without explicit programming',
    'Three main types: Supervised, Unsupervised, Reinforcement Learning',
    'Supervised learning requires labeled training data',
    'Overfitting occurs when a model memorizes training data but fails on new data',
    'Neural networks are inspired by the structure of the human brain',
    'Model evaluation uses metrics like accuracy, precision, recall, and F1-score',
  ],
  importantQuestions: [
    'What is the difference between supervised and unsupervised learning?',
    'How does gradient descent work in neural networks?',
    'What techniques prevent overfitting in ML models?',
    'When should you use a decision tree vs. a neural network?',
    'How do you evaluate a machine learning model\'s performance?',
  ],
  topics: ['Machine Learning', 'Neural Networks', 'Python', 'Data Science', 'AI Algorithms'],
  youtubeVideos: [
    { title: 'Machine Learning Full Course - Simplilearn', channel: 'Simplilearn', duration: '9:22:00', views: '4.2M' },
    { title: 'Neural Networks Explained - 3Blue1Brown', channel: '3Blue1Brown', duration: '19:13', views: '14M' },
    { title: 'Supervised vs Unsupervised Learning', channel: 'StatQuest', duration: '12:44', views: '2.8M' },
    { title: 'Decision Trees and Random Forests', channel: 'Josh Starmer', duration: '17:21', views: '1.1M' },
  ],
  flowchart: [
    { id: 'A', label: 'Raw Data', type: 'start' },
    { id: 'B', label: 'Data Preprocessing', type: 'process' },
    { id: 'C', label: 'Feature Engineering', type: 'process' },
    { id: 'D', label: 'Model Selection', type: 'decision' },
    { id: 'E', label: 'Model Training', type: 'process' },
    { id: 'F', label: 'Evaluation', type: 'process' },
    { id: 'G', label: 'Good Enough?', type: 'decision' },
    { id: 'H', label: 'Deployment', type: 'end' },
  ],
  numericalData: [
    { algorithm: 'Linear Reg', accuracy: 78 },
    { algorithm: 'Decision Tree', accuracy: 82 },
    { algorithm: 'Random Forest', accuracy: 89 },
    { algorithm: 'SVM', accuracy: 85 },
    { algorithm: 'Neural Net', accuracy: 93 },
  ],
};

// AI chatbot responses (deterministic mock)
export const getChatbotResponse = (message) => {
  const m = message.toLowerCase();
  if (m.includes('neural') || m.includes('network'))
    return `**Neural Networks** are computing systems inspired by the biological neural networks in our brains.\n\n**How they work:**\n1. Receive input data (text, image, numbers)\n2. Pass through layers of interconnected "neurons"\n3. Each neuron applies a mathematical transformation\n4. Output a prediction or classification\n\n**Key components:**\n- **Input Layer** → receives raw data\n- **Hidden Layers** → learn complex patterns\n- **Output Layer** → produces final prediction\n- **Weights & Biases** → learned parameters\n- **Activation Functions** → introduce non-linearity (ReLU, Sigmoid, Tanh)\n\nWant me to generate a quiz on neural networks, or explain backpropagation?`;
  if (m.includes('overfit'))
    return `**Overfitting** happens when a model learns the training data *too well*, including noise, and fails to generalize.\n\n**Signs of overfitting:**\n- High training accuracy, low test accuracy\n- Loss diverges between train/validation sets\n\n**How to prevent it:**\n1. **Regularization** (L1/L2) — penalizes complexity\n2. **Dropout** — randomly disables neurons during training\n3. **Early stopping** — halt training before overfitting begins\n4. **More data** — larger datasets reduce overfitting\n5. **Cross-validation** — robust performance estimation\n\n*Think of it like a student who memorizes answers but can't apply the concept.*`;
  if (m.includes('gradient') || m.includes('descent'))
    return `**Gradient Descent** is the optimization algorithm that trains neural networks.\n\n**The intuition:**\nImagine you're blindfolded on a hilly terrain trying to reach the lowest valley. You feel the slope under your feet and take a step downhill. Repeat until you reach the bottom — that's gradient descent!\n\n**Algorithm:**\n\`\`\`\nθ = θ - α × ∇L(θ)\n\`\`\`\nWhere:\n- θ = model parameters\n- α = learning rate\n- ∇L = gradient of the loss function\n\n**Variants:**\n- **SGD** (Stochastic) — updates per sample, noisy but fast\n- **Mini-batch GD** — updates per small batch, balanced\n- **Adam** — adaptive learning rate, most popular today`;
  if (m.includes('quiz') || m.includes('test me'))
    return `Here's a quick quiz on Machine Learning! 🎯\n\n**Q1.** What type of learning requires labeled training data?\n a) Unsupervised  b) Supervised  c) Reinforcement  d) Transfer\n\n**Q2.** Which metric is best for imbalanced datasets?\n a) Accuracy  b) MSE  c) F1-Score  d) R²\n\n**Q3.** Dropout is used to prevent:\n a) Underfitting  b) Overfitting  c) Slow training  d) Data loss\n\n**Q4.** The activation function that returns 0 for negative inputs is:\n a) Sigmoid  b) Tanh  c) ReLU  d) Softmax\n\nReply with your answers (e.g., "b, c, b, c") and I'll grade them!`;
  if (m.includes('summary') || m.includes('summarize'))
    return `Based on the uploaded PDF **"Introduction to Machine Learning"**, here's a structured summary:\n\n**Core Concepts:**\n- Machine Learning = AI systems that learn from data\n- Three learning paradigms: Supervised, Unsupervised, Reinforcement\n\n**Key Algorithms:**\n| Algorithm | Type | Best For |\n|---|---|---|\n| Linear Regression | Supervised | Numerical prediction |\n| Decision Tree | Supervised | Classification |\n| K-Means | Unsupervised | Clustering |\n| Q-Learning | Reinforcement | Sequential decisions |\n\n**Workflow:** Data → Preprocessing → Training → Evaluation → Deployment\n\n*Want a deeper dive into any specific section?*`;
  return `That's a great question! Based on the uploaded document and my knowledge:\n\n**${message}** is an important concept in the field of machine learning and AI.\n\nHere's what you need to know:\n\n1. **Definition** — This concept relates to how algorithms process and learn from data patterns\n2. **Importance** — Understanding this helps in building more accurate and efficient models\n3. **Practical Application** — Used widely in real-world AI systems including recommendation engines and NLP\n\n**Key insight:** Always start with simpler models before moving to complex ones — this is known as the parsimony principle.\n\nWould you like me to:\n- Generate examples for this concept?\n- Create a quiz to test your understanding?\n- Explain a related concept?`;
};
