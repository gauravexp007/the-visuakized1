import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  BarChart, Bar, LineChart, Line, AreaChart, Area, PieChart, Pie, Cell,
  RadarChart, Radar, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import { TrendingUp, Target, Clock, Award, BookOpen, Code2, Video, PenLine, Filter, Download } from 'lucide-react';
import Card from '../components/ui/Card';
import Badge from '../components/ui/Badge';
import Button from '../components/ui/Button';

// ── Extended mock data ───────────────────────────────────────────────────────
const monthlyHours = [
  { month: 'Oct', hours: 58, target: 80 },
  { month: 'Nov', hours: 74, target: 80 },
  { month: 'Dec', hours: 62, target: 80 },
  { month: 'Jan', hours: 85, target: 90 },
  { month: 'Feb', hours: 91, target: 90 },
  { month: 'Mar', hours: 73, target: 90 },
];

const skillRadar = [
  { skill: 'React',       score: 85 },
  { skill: 'Python',      score: 72 },
  { skill: 'ML/AI',       score: 68 },
  { skill: 'System Design',score: 55 },
  { skill: 'DSA',         score: 78 },
  { skill: 'SQL',         score: 88 },
];

const heatmapData = Array.from({ length: 7 }, (_, row) =>
  Array.from({ length: 12 }, (_, col) => ({
    day: ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'][row],
    week: `W${col+1}`,
    value: Math.floor(Math.random() * 5),
  }))
).flat();

const subjectProgress = [
  { subject: 'Machine Learning', progress: 72, color: '#6366f1', sessions: 14 },
  { subject: 'Web Development',  progress: 88, color: '#8b5cf6', sessions: 22 },
  { subject: 'Data Structures',  progress: 55, color: '#06b6d4', sessions: 8  },
  { subject: 'System Design',    progress: 41, color: '#10b981', sessions: 5  },
  { subject: 'Database / SQL',   progress: 90, color: '#f59e0b', sessions: 18 },
];

const platformData = [
  { platform: 'Coding',  Mon:90, Tue:120, Wed:60, Thu:150, Fri:100, Sat:180, Sun:90 },
  { platform: 'Reading', Mon:45, Tue:60,  Wed:30, Thu:75,  Fri:45,  Sat:90,  Sun:60 },
  { platform: 'Videos',  Mon:30, Tue:30,  Wed:30, Thu:45,  Fri:30,  Sat:60,  Sun:30 },
];

const days = ['Mon','Tue','Wed','Thu','Fri','Sat','Sun'];
const stackedData = days.map(d => ({
  day: d,
  Coding:  platformData[0][d],
  Reading: platformData[1][d],
  Videos:  platformData[2][d],
}));

const COLORS = ['#6366f1','#8b5cf6','#06b6d4','#10b981','#f59e0b'];

function ChartTooltip({ active, payload, label }) {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl p-3 shadow-xl text-sm">
      <p className="font-semibold text-slate-900 dark:text-white mb-2">{label}</p>
      {payload.map((p, i) => (
        <div key={i} className="flex items-center gap-2">
          <span className="w-2 h-2 rounded-full" style={{ background: p.color || p.fill }} />
          <span className="text-slate-600 dark:text-slate-400">{p.name}:</span>
          <span className="font-semibold text-slate-900 dark:text-white">{p.value}{p.unit || ''}</span>
        </div>
      ))}
    </div>
  );
}

const fadeIn = (delay = 0) => ({
  initial: { opacity: 0, y: 16 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4, delay },
});

// ── Heatmap ──────────────────────────────────────────────────────────────────
function ActivityHeatmap() {
  const colors = ['#f1f5f9','#c7d2fe','#818cf8','#6366f1','#4338ca'];
  const darkColors = ['#1e293b','#1e1b4b','#3730a3','#4338ca','#6366f1'];

  return (
    <div className="overflow-x-auto">
      <div className="min-w-[480px]">
        <div className="flex gap-1 mb-1">
          <div className="w-8" />
          {Array.from({ length: 12 }, (_, i) => (
            <div key={i} className="flex-1 text-center text-xs text-slate-400">W{i+1}</div>
          ))}
        </div>
        {['Mon','Tue','Wed','Thu','Fri','Sat','Sun'].map(day => (
          <div key={day} className="flex items-center gap-1 mb-1">
            <div className="w-8 text-xs text-slate-400 text-right pr-2">{day}</div>
            {Array.from({ length: 12 }, (_, col) => {
              const cell = heatmapData.find(c => c.day === day && c.week === `W${col+1}`);
              const v = cell?.value ?? 0;
              return (
                <div
                  key={col}
                  title={`${day} W${col+1}: ${v}h`}
                  className="flex-1 h-5 rounded-sm cursor-pointer transition-transform hover:scale-125 dark:hidden"
                  style={{ background: colors[v] }}
                />
              );
            })}
            {Array.from({ length: 12 }, (_, col) => {
              const cell = heatmapData.find(c => c.day === day && c.week === `W${col+1}`);
              const v = cell?.value ?? 0;
              return (
                <div
                  key={`d${col}`}
                  title={`${day} W${col+1}: ${v}h`}
                  className="flex-1 h-5 rounded-sm cursor-pointer transition-transform hover:scale-125 hidden dark:block"
                  style={{ background: darkColors[v] }}
                />
              );
            })}
          </div>
        ))}
        <div className="flex items-center gap-2 mt-3 justify-end">
          <span className="text-xs text-slate-400">Less</span>
          {[0,1,2,3,4].map(v => (
            <div key={v} className="w-3 h-3 rounded-sm dark:hidden" style={{ background: colors[v] }} />
          ))}
          {[0,1,2,3,4].map(v => (
            <div key={`d${v}`} className="w-3 h-3 rounded-sm hidden dark:block" style={{ background: darkColors[v] }} />
          ))}
          <span className="text-xs text-slate-400">More</span>
        </div>
      </div>
    </div>
  );
}

// ── Subject progress bars ────────────────────────────────────────────────────
function SubjectBar({ subject, progress, color, sessions, delay }) {
  return (
    <motion.div {...fadeIn(delay)} className="space-y-1.5">
      <div className="flex items-center justify-between text-sm">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full shrink-0" style={{ background: color }} />
          <span className="font-medium text-slate-700 dark:text-slate-300">{subject}</span>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-xs text-slate-400">{sessions} sessions</span>
          <span className="font-bold text-slate-900 dark:text-white">{progress}%</span>
        </div>
      </div>
      <div className="h-2 bg-slate-100 dark:bg-slate-800 rounded-full overflow-hidden">
        <motion.div
          initial={{ width: 0 }}
          animate={{ width: `${progress}%` }}
          transition={{ duration: 0.9, delay: delay + 0.3, ease: 'easeOut' }}
          className="h-full rounded-full"
          style={{ background: color }}
        />
      </div>
    </motion.div>
  );
}

// ── Main ─────────────────────────────────────────────────────────────────────
export default function VisualInsights() {
  const [range, setRange] = useState('week');

  return (
    <div className="space-y-6">
      {/* Controls */}
      <motion.div {...fadeIn(0)} className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">Analytics Overview</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">AI-powered insights into your learning patterns</p>
        </div>
        <div className="flex items-center gap-2">
          {['week','month','3m'].map(r => (
            <button key={r} onClick={() => setRange(r)}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors ${
                range === r
                  ? 'bg-indigo-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200 dark:hover:bg-slate-700'
              }`}>
              {r === '3m' ? '3 Months' : r.charAt(0).toUpperCase() + r.slice(1)}
            </button>
          ))}
          <Button variant="outline" size="sm" icon={Download}>Export</Button>
        </div>
      </motion.div>

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {[
          { icon: Clock,    label: 'Total Hours',    value: '73h',   sub: 'This month', trend: +8,  color: 'indigo' },
          { icon: Target,   label: 'Goal Completion',value: '81%',   sub: 'Monthly avg', trend: +5, color: 'emerald' },
          { icon: Award,    label: 'Consistency',    value: '7-day', sub: 'Current streak', trend: 0, color: 'amber' },
          { icon: TrendingUp,label:'Skill Growth',   value: '+18%',  sub: 'Past 30 days', trend: +18, color: 'purple' },
        ].map((s, i) => (
          <motion.div key={s.label} {...fadeIn(i * 0.07)}>
            <Card hover>
              <div className="flex items-center justify-between mb-3">
                <div className={`p-2 rounded-lg ${
                  { indigo:'bg-indigo-50 dark:bg-indigo-950/40', emerald:'bg-emerald-50 dark:bg-emerald-950/40', amber:'bg-amber-50 dark:bg-amber-950/40', purple:'bg-purple-50 dark:bg-purple-950/40' }[s.color]
                }`}>
                  <s.icon size={16} className={`text-${s.color}-500`} style={{ color: { indigo:'#6366f1', emerald:'#10b981', amber:'#f59e0b', purple:'#8b5cf6' }[s.color] }} />
                </div>
                {s.trend !== 0 && (
                  <Badge variant={s.trend > 0 ? 'success' : 'danger'}>{s.trend > 0 ? '+' : ''}{s.trend}%</Badge>
                )}
              </div>
              <p className="text-xl font-bold text-slate-900 dark:text-white">{s.value}</p>
              <p className="text-sm text-slate-600 dark:text-slate-400">{s.label}</p>
              <p className="text-xs text-slate-400 dark:text-slate-600">{s.sub}</p>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Stacked bar + Radar */}
      <div className="grid lg:grid-cols-3 gap-4">
        <motion.div {...fadeIn(0.2)} className="lg:col-span-2">
          <Card>
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-base font-semibold text-slate-900 dark:text-white">Platform Activity (minutes)</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">Weekly breakdown per platform</p>
              </div>
              <Badge variant="indigo"><Filter size={10} /> Stacked</Badge>
            </div>
            <ResponsiveContainer width="100%" height={230}>
              <BarChart data={stackedData} barSize={28}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-slate-200 dark:stroke-slate-800" vertical={false} />
                <XAxis dataKey="day" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} unit="m" />
                <Tooltip content={<ChartTooltip />} cursor={{ fill: 'rgba(99,102,241,0.06)' }} />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
                <Bar dataKey="Coding"  stackId="a" fill="#6366f1" radius={[0,0,0,0]} />
                <Bar dataKey="Reading" stackId="a" fill="#8b5cf6" />
                <Bar dataKey="Videos"  stackId="a" fill="#06b6d4" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </motion.div>

        {/* Radar */}
        <motion.div {...fadeIn(0.3)}>
          <Card className="h-full">
            <h3 className="text-base font-semibold text-slate-900 dark:text-white mb-1">Skill Assessment</h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mb-3">Current proficiency levels</p>
            <ResponsiveContainer width="100%" height={220}>
              <RadarChart data={skillRadar}>
                <PolarGrid stroke="#e2e8f0" className="dark:stroke-slate-700" />
                <PolarAngleAxis dataKey="skill" tick={{ fontSize: 11, fill: '#94a3b8' }} />
                <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fontSize: 10, fill: '#94a3b8' }} />
                <Radar name="Skill" dataKey="score" stroke="#6366f1" fill="#6366f1" fillOpacity={0.25} strokeWidth={2} />
              </RadarChart>
            </ResponsiveContainer>
          </Card>
        </motion.div>
      </div>

      {/* Area chart */}
      <motion.div {...fadeIn(0.35)}>
        <Card>
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="text-base font-semibold text-slate-900 dark:text-white">Monthly Progress vs Target</h3>
              <p className="text-xs text-slate-500 dark:text-slate-400">Hours studied vs monthly goal</p>
            </div>
            <Badge variant="success">↑ 15% above average</Badge>
          </div>
          <ResponsiveContainer width="100%" height={200}>
            <AreaChart data={monthlyHours}>
              <defs>
                <linearGradient id="hoursGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#6366f1" stopOpacity={0.3} />
                  <stop offset="95%" stopColor="#6366f1" stopOpacity={0} />
                </linearGradient>
                <linearGradient id="targetGrad" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%"  stopColor="#10b981" stopOpacity={0.15} />
                  <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" className="stroke-slate-200 dark:stroke-slate-800" vertical={false} />
              <XAxis dataKey="month" tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 12, fill: '#94a3b8' }} axisLine={false} tickLine={false} unit="h" />
              <Tooltip content={<ChartTooltip />} />
              <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
              <Area type="monotone" dataKey="target" name="Target" stroke="#10b981" strokeWidth={2} strokeDasharray="6 3" fill="url(#targetGrad)" />
              <Area type="monotone" dataKey="hours"  name="Actual" stroke="#6366f1" strokeWidth={3} fill="url(#hoursGrad)" dot={{ fill: '#6366f1', r: 4, strokeWidth: 2, stroke: '#fff' }} />
            </AreaChart>
          </ResponsiveContainer>
        </Card>
      </motion.div>

      {/* Subject progress + Heatmap */}
      <div className="grid lg:grid-cols-2 gap-4">
        <motion.div {...fadeIn(0.4)}>
          <Card>
            <div className="flex items-center justify-between mb-5">
              <div>
                <h3 className="text-base font-semibold text-slate-900 dark:text-white">Subject Progress</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">Completion by topic</p>
              </div>
              <Badge variant="warning"><BookOpen size={10} /> Focus needed</Badge>
            </div>
            <div className="space-y-4">
              {subjectProgress.map((s, i) => (
                <SubjectBar key={s.subject} {...s} delay={0.45 + i * 0.06} />
              ))}
            </div>
          </Card>
        </motion.div>

        <motion.div {...fadeIn(0.45)}>
          <Card>
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-semibold text-slate-900 dark:text-white">Activity Heatmap</h3>
                <p className="text-xs text-slate-500 dark:text-slate-400">Study consistency over 12 weeks</p>
              </div>
              <Badge variant="indigo"><Code2 size={10} /> 73 active days</Badge>
            </div>
            <ActivityHeatmap />
          </Card>
        </motion.div>
      </div>

      {/* AI insights block */}
      <motion.div {...fadeIn(0.5)}>
        <Card className="border-indigo-200 dark:border-indigo-900 bg-gradient-to-r from-indigo-50/50 to-purple-50/50 dark:from-indigo-950/20 dark:to-purple-950/20">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
              <TrendingUp size={16} className="text-white" />
            </div>
            <h3 className="text-base font-semibold text-slate-900 dark:text-white">AI-Generated Study Plan</h3>
            <Badge variant="indigo" className="ml-auto">Personalized</Badge>
          </div>
          <div className="grid sm:grid-cols-3 gap-3">
            {[
              { day: 'Tomorrow',   task: 'DSA: Binary Trees',       time: '2h', priority: 'High' },
              { day: 'This Week',  task: 'System Design: Caching',  time: '3h', priority: 'Medium' },
              { day: 'This Month', task: 'ML: Finish CNN module',    time: '6h', priority: 'Medium' },
            ].map(p => (
              <div key={p.day} className="bg-white dark:bg-slate-900/50 rounded-xl p-3 border border-slate-200 dark:border-slate-800">
                <Badge variant={p.priority === 'High' ? 'danger' : 'warning'} className="mb-2 text-xs">
                  {p.priority}
                </Badge>
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-200">{p.task}</p>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{p.day} · {p.time}</p>
              </div>
            ))}
          </div>
        </Card>
      </motion.div>
    </div>
  );
}
